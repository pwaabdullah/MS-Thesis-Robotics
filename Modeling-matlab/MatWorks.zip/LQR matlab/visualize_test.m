
% example trajectory
xx = [linspace(3, -2) linspace(-2, 3)];
yy = [linspace(4, 4) linspace(1, 1)];
thth = [linspace(0,0) linspace(0,0)];
visualize([xx; yy; thth], [xx; yy; thth]);
