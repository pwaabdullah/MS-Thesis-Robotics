# BLDC Motor Modeling

This directory contains MATLAB/Simulink files for modeling brushless DC (BLDC) motors.  It is not a part of the simulation setup in the parent directory.
