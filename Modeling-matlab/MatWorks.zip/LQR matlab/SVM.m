clear;
clc;
close all;

load fisheriris;